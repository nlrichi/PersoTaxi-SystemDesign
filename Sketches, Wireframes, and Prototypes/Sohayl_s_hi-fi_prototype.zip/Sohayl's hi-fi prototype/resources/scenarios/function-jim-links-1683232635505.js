(function(window, undefined) {

  var jimLinks = {
    "213e4634-38a0-4cf7-b772-a15f66e11415" : {
      "Ellipse_1" : [
        "0f1cccbd-c311-4636-9c3f-cf148b84211d"
      ],
      "Subtraction_4" : [
        "0f1cccbd-c311-4636-9c3f-cf148b84211d"
      ]
    },
    "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3" : {
      "Path_13" : [
        "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"
      ],
      "Path_20" : [
        "213e4634-38a0-4cf7-b772-a15f66e11415"
      ],
      "Path_21" : [
        "057180fa-c892-47c0-8659-cbb0b2fa9573"
      ],
      "Path_22" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "0f1cccbd-c311-4636-9c3f-cf148b84211d" : {
    },
    "057180fa-c892-47c0-8659-cbb0b2fa9573" : {
      "Path_31" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_24" : [
        "057180fa-c892-47c0-8659-cbb0b2fa9573"
      ],
      "Path_25" : [
        "057180fa-c892-47c0-8659-cbb0b2fa9573"
      ],
      "Path_39" : [
        "213e4634-38a0-4cf7-b772-a15f66e11415"
      ],
      "Path_4" : [
        "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "057180fa-c892-47c0-8659-cbb0b2fa9573"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);