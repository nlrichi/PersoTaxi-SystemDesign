	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Image_2", "213e4634-38a0-4cf7-b772-a15f66e11415"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "213e4634-38a0-4cf7-b772-a15f66e11415"]] = ["Refresh control", "s-Image_2"]; 

	widgets.descriptionMap[["s-Path_20", "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"]] = ["Person square", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_22", "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"]] = ["Home", "s-Path_22"]; 

	widgets.descriptionMap[["s-Button_1", "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "2c63fc64-eca5-4b4a-bc58-eff7b74eb9d3"]] = ["Filled button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Text_16", "0f1cccbd-c311-4636-9c3f-cf148b84211d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "0f1cccbd-c311-4636-9c3f-cf148b84211d"]] = ["Progress indicator", "s-Checking"]; 

	widgets.descriptionMap[["s-Image_2", "0f1cccbd-c311-4636-9c3f-cf148b84211d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "0f1cccbd-c311-4636-9c3f-cf148b84211d"]] = ["Progress indicator", "s-Checking"]; 

	widgets.descriptionMap[["s-Button_1", "0f1cccbd-c311-4636-9c3f-cf148b84211d"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "0f1cccbd-c311-4636-9c3f-cf148b84211d"]] = ["Filled", "s-Button_1"]; 

	widgets.descriptionMap[["s-Image", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_31", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Path_31", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Home", "s-Path_31"]; 

	widgets.descriptionMap[["s-Path_24", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Path_24", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Map pin", "s-Group_11"]; 

	widgets.descriptionMap[["s-Path_25", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Map pin", "s-Group_11"]; 

	widgets.descriptionMap[["s-Image_1", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Path_39", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Path_39", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Person square", "s-Path_39"]; 

	widgets.descriptionMap[["s-Path_4", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Settings", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_30", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Path_30", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Wifi", "s-Path_30"]; 

	widgets.descriptionMap[["s-Path_11", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Battery half", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_51", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Path_51", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Location", "s-Path_51"]; 

	widgets.descriptionMap[["s-Input_8", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Toggle", "s-Input_8"]; 

	widgets.descriptionMap[["s-Rectangle_1", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Slider", "s-Table_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Slider", "s-Table_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Slider", "s-Table_1"]; 

	widgets.descriptionMap[["s-Panel_1", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Slider", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_3", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_3", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Slider", "s-Table_1"]; 

	widgets.descriptionMap[["s-Path_63", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Path_63", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Person", "s-Path_63"]; 

	widgets.descriptionMap[["s-Rectangle_6", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Image pressed", "s-Group_29"]; 

	widgets.descriptionMap[["s-Rectangle_17", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Alert paired actions", "s-Group_44"]; 

	widgets.descriptionMap[["s-Paragraph_16", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Alert paired actions", "s-Group_44"]; 

	widgets.descriptionMap[["s-Paragraph_17", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Alert paired actions", "s-Group_44"]; 

	widgets.descriptionMap[["s-Rectangle_9", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Alert paired actions", "s-Group_44"]; 

	widgets.descriptionMap[["s-Paragraph_18", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Alert paired actions", "s-Group_44"]; 

	widgets.descriptionMap[["s-Category_2", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "057180fa-c892-47c0-8659-cbb0b2fa9573"]] = ["Select list", "s-Category_2"]; 

	widgets.descriptionMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Input-text_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input-text_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input text field", "s-Input-text_6"]; 

	widgets.descriptionMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Password", "s-List-item-4_6"]; 

	