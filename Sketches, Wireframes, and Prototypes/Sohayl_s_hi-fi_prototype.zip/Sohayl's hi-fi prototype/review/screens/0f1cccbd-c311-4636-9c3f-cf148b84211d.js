var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1683232635505.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-0f1cccbd-c311-4636-9c3f-cf148b84211d" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Terms of Service" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/0f1cccbd-c311-4636-9c3f-cf148b84211d-1683232635505.css" />\
      <div class="freeLayout">\
      <div id="s-Checking" class="group firer ie-background commentable hidden non-processed" customid="Progress Indicator" datasizewidth="185.0px" datasizeheight="21.0px" >\
        <div id="s-Text_16" class="richtext autofit firer ie-background commentable non-processed" customid="Checking for Update&hellip;"   datasizewidth="157.2px" datasizeheight="21.0px" dataX="83.7" dataY="312.6" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_16_0">Checking for Update&hellip;</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_2" class="image lockV firer ie-background commentable non-processed" customid="Spinner icon"   datasizewidth="57.3px" datasizeheight="57.3px" dataX="287.4" dataY="301.6" aspectRatio="1.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/2a746fa2-fcbe-4a8a-9b39-ebbc6d6dd4bc.gif" />\
          	</div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Button Filled"   datasizewidth="330.0px" datasizeheight="75.0px" dataX="49.0" dataY="735.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">UPLOAD</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Browser_1" class="url firer ie-background commentable non-processed" datasizewidth="330.0px" datasizeheight="133.0px" dataX="49.0" dataY="552.0" >\
        <div class="commentpanel hidden"></div>\
        <div class="borderLayer">\
        	<iframe width="100%" height="100%" src="https://www.google.com/search?q=captcha+code+&amp;client=avast-a-2&amp;sxsrf=APwXEdc5p06h3i6uKjBQAKypfMD4mBH4oA%3A1683232362269&amp;ei=ahZUZPmPEIfCgQaL_YGwDQ&amp;ved=0ahUKEwj57JuYwdz-AhUHYcAKHYt-ANYQ4dUDCA8&amp;uact=5&amp;oq=captcha+code+&amp;gs_lcp=Cgxnd3Mtd2l6LXNlcnAQAzIHCCMQigUQJzIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEMgUIABCABDoKCAAQRxDWBBCwAzoNCAAQ5AIQ1gQQsAMYAToGCAAQFhAeOggIABCKBRCGAzoICAAQFhAeEA9KBAhBGABQZ1iCBWDTBmgBcAF4AIABoQGIAZ4EkgEDMC40mAEAoAEByAELwAEB2gEGCAEQARgJ&amp;sclient=gws-wiz-serp" marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" sandbox="allow-scripts"></iframe>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Document Upload"   datasizewidth="288.2px" datasizeheight="41.0px" dataX="34.0" dataY="82.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Document Upload</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_1" class="selectionlist firer commentable non-processed" customid="Category 1"    datasizewidth="378.0px" datasizeheight="304.0px" dataX="34.0" dataY="221.6"   tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="scroll">\
            <div class="paddingLayer">\
              <table style="height: 100%; width: 100%;" summary="">\
                <tbody>\
                  <tr>\
                    <td >\
                      <div class="option ">new value 1</div>\
                      <div class="option ">new value 2</div>\
                      <div class="option ">new value 3</div>\
                    </td>\
                  </tr>\
                </tbody>\
              </table>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;