var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1683232635505.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-213e4634-38a0-4cf7-b772-a15f66e11415" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Account" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/213e4634-38a0-4cf7-b772-a15f66e11415-1683232635505.css" />\
      <div class="freeLayout">\
      <div id="s-Input_1" class="email text firer commentable non-processed" customid="Input 1"  datasizewidth="340.0px" datasizeheight="87.0px" dataX="21.0" dataY="264.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="email"  value="" maxlength="100"  tabindex="-1" placeholder="Email"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="340.0px" datasizeheight="79.0px" dataX="21.0" dataY="384.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Password" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Category_1" class="dropdown firer commentable non-processed" customid="Category 1"    datasizewidth="340.0px" datasizeheight="53.0px" dataX="21.0" dataY="501.4"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Date of Birth</div></div></div></div></div><select id="s-Category_1-options" class="s-213e4634-38a0-4cf7-b772-a15f66e11415 dropdown-options" ><option selected="selected" class="option">Date of Birth</option>\
      <option  class="option">April 21st 2003</option>\
      <option  class="option">april 22nd 2003</option>\
      <option  class="option">April 23rd 2003</option></select></div>\
      <div id="s-Input_3" class="number text firer commentable non-processed" customid="Input 3"  datasizewidth="340.0px" datasizeheight="66.0px" dataX="21.0" dataY="585.8" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="number"  value="Phone" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="193.9px" datasizeheight="171.2px" datasizewidthpx="193.92499276161277" datasizeheightpx="171.2401682230402" dataX="69.5" dataY="669.9" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse" cx="96.96249638080639" cy="85.6200841115201" rx="96.96249638080639" ry="85.6200841115201">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="96.96249638080639" cy="85.6200841115201" rx="96.96249638080639" ry="85.6200841115201">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Subtraction_4" class="path firer click commentable non-processed" customid="Add icon"   datasizewidth="93.0px" datasizeheight="81.9px" dataX="121.6" dataY="714.3"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="93.48025512695312" height="82.35826110839844" viewBox="121.6136363636349 714.320870823054 93.48025512695312 82.35826110839844" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Subtraction_4-213e4" d="M168.34663042615097 715.0708784508786 C168.35174153075207 715.0708784508786 168.3571216408585 715.0708784508786 168.3622327454596 715.0708784508786 C170.68079119579397 715.0708784508786 172.56947884863047 716.7311911047278 172.56947884863047 718.7768448025095 L172.52751398980092 751.7940336483687 L210.1280275011079 751.7940336483687 C212.45519412761274 751.7940336483687 214.34388178044924 753.454228063174 214.34388178044924 755.4999999999998 C214.34388178044924 757.5383228770619 212.45519412761274 759.2059663516304 210.1280275011079 759.2059663516304 L172.51890581363074 759.2059663516304 L172.468332778631 792.2304860182089 C172.468332778631 794.2643158116047 170.5879842964594 795.9291215491205 168.26808081859832 795.9291215491205 C168.26270070849188 795.9291215491205 168.25758960389078 795.9291215491205 168.25247849928996 795.9291215491205 C165.92558087829042 795.9291215491205 164.03689322545392 794.2688088952711 164.03689322545392 792.2231551974894 L164.08746626045365 759.2059663516304 L126.57949064297594 759.2059663516304 C124.25232401647139 759.2059663516304 122.3636363636349 757.5383228770619 122.3636363636349 755.4999999999998 C122.3636363636349 753.454228063174 124.25232401647139 751.7940336483687 126.57949064297594 751.7940336483687 L164.09580543111855 751.7940336483687 L164.13803929545338 718.7695139817904 C164.14637846611828 716.7283533676754 166.02672694828988 715.0708784508786 168.34663042615097 715.0708784508786 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_4-213e4" fill="#FFFFFF" fill-opacity="1.0" stroke-width="0.5" stroke="#FFFFFF" stroke-linecap="square"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image lockV firer ie-background commentable hidden non-processed" customid="Refresh control"   datasizewidth="309.0px" datasizeheight="309.0px" dataX="59.5" dataY="308.5" aspectRatio="1.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/2c536f3b-13bb-408e-84b5-1670124dda94.gif" />\
        	</div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;