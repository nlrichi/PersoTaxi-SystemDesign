var content='<div class="ui-page" deviceName="iphone13promax" deviceType="mobile" deviceWidth="428" deviceHeight="926">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1683232635505.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Log in screen" width="428" height="926">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1683232635505.css" />\
      <div class="freeLayout">\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="LOG IN"   datasizewidth="372.0px" datasizeheight="83.0px" dataX="28.0" dataY="513.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">LOG IN </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="428.0px" datasizeheight="213.3px" dataX="0.0" dataY="27.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="resources/jim/images/common/cross.svg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="13.0" dataY="611.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Forgot Password/help"/></div></div>  </div></div></div>\
\
      <div id="s-List-item-4_6" class="group firer ie-background commentable non-processed" customid="Password Field" datasizewidth="0.0px" datasizeheight="44.0px" >\
        <div id="s-Input-text_6" class="password firer commentable non-processed" customid="Input-text"  datasizewidth="355.1px" datasizeheight="44.0px" dataX="13.0" dataY="388.8" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="********"/></div></div></div></div></div>\
        <div id="s-Path_11" class="path firer ie-background commentable non-processed" customid="Line"   datasizewidth="345.5px" datasizeheight="3.0px" dataX="23.6" dataY="430.8"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="345.472412109375" height="2.0" viewBox="23.615009427603724 430.80397556948714 345.472412109375 2.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_11-d1224" d="M24.61494839244733 431.80405949282704 L368.0873464331298 431.80405949282704 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-d1224" fill="none" stroke-width="1.0" stroke="#3C3C4332" stroke-linecap="square" opacity="0.8"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="13.0" dataY="344.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Username"/></div></div>  </div></div></div>\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Facebook"   datasizewidth="372.0px" datasizeheight="60.0px" dataX="28.0" dataY="796.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Facebook</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;